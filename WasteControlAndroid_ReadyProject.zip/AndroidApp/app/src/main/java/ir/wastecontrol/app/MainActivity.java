package ir.wastecontrol.app;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.view.WindowManager;
import androidx.webkit.WebViewAssetLoader;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import java.util.concurrent.Executor;
import android.os.Looper;

public class MainActivity extends FragmentActivity {
    // Durable offline authentication data, stored outside WebView DOM storage.
    public static class OfflineStorageBridge {
        private final SharedPreferences prefs;
        OfflineStorageBridge(Context context) {
            prefs = context.getSharedPreferences("waste_offline_auth", Context.MODE_PRIVATE);
        }
        @JavascriptInterface public String loadSession() { return prefs.getString("session", ""); }
        @JavascriptInterface public boolean saveSession(String value) { return prefs.edit().putString("session", value == null ? "" : value).commit(); }
        @JavascriptInterface public void clearSession() { prefs.edit().remove("session").commit(); }
        @JavascriptInterface public boolean saveCredential(String username, String password) {
            try {
                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                byte[] hash = derive(password, salt);
                return prefs.edit()
                    .putString("credential_username", username)
                    .putString("credential_salt", toHex(salt))
                    .putString("credential_hash", toHex(hash))
                    .putInt("credential_iterations", 150000)
                    .commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public boolean verifyCredential(String username, String password) {
            try {
                if (!username.equals(prefs.getString("credential_username", ""))) return false;
                String saltHex = prefs.getString("credential_salt", "");
                String hashHex = prefs.getString("credential_hash", "");
                if (saltHex.length() != 32 || hashHex.length() != 64) return false;
                byte[] actual = derive(password, fromHex(saltHex));
                return MessageDigest.isEqual(actual, fromHex(hashHex));
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void clearCredential() {
            prefs.edit().remove("credential_username").remove("credential_salt")
                .remove("credential_hash").remove("credential_iterations")
                .putBoolean("biometric_enabled", false).commit();
        }
        @JavascriptInterface public boolean biometricEnabled() { return prefs.getBoolean("biometric_enabled", false); }
        @JavascriptInterface public void setBiometricEnabled(boolean enabled) { prefs.edit().putBoolean("biometric_enabled", enabled).commit(); }
        private static byte[] derive(String password, byte[] salt) throws Exception {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 150000, 256);
            try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
            finally { spec.clearPassword(); }
        }
        private static String toHex(byte[] bytes) {
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
            return out.toString();
        }
        private static byte[] fromHex(String hex) {
            byte[] out = new byte[hex.length() / 2];
            for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
            return out;
        }
    }
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo biometricPromptInfo;

    private class BiometricBridge {
        @JavascriptInterface public boolean isAvailable() {
            return BiometricManager.from(MainActivity.this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
        }
        @JavascriptInterface public String availabilityMessage() {
            int result = BiometricManager.from(MainActivity.this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
            if (result == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) return "برای استفاده از ورود با اثر انگشت، ابتدا اثر انگشت خود را در تنظیمات گوشی ثبت کنید.";
            if (result == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE) return "این دستگاه حسگر بیومتریک سازگار ندارد.";
            if (result == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) return "حسگر اثر انگشت فعلاً در دسترس نیست.";
            if (result == BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED) return "برای استفاده از اثر انگشت، به‌روزرسانی امنیتی گوشی لازم است.";
            return "ورود با اثر انگشت در حال حاضر در دسترس نیست.";
        }
        @JavascriptInterface public boolean isEnabled() {
            return getSharedPreferences("waste_offline_auth", MODE_PRIVATE).getBoolean("biometric_enabled", false);
        }
        @JavascriptInterface public void enable(String callback) { runBiometric(callback, true); }
        @JavascriptInterface public void authenticate(String callback) { runBiometric(callback, false); }
        private void runBiometric(String callback, boolean enabling) {
            if (callback == null || !callback.matches("[A-Za-z_$][A-Za-z0-9_$]*")) return;
            runOnUiThread(() -> {
                if (!isAvailable()) { sendResult(callback, false, "اثر انگشت قوی در گوشی فعال یا در دسترس نیست."); return; }
                biometricPrompt = new BiometricPrompt(MainActivity.this, command -> MainActivity.this.runOnUiThread(command), new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        if (enabling) getSharedPreferences("waste_offline_auth", MODE_PRIVATE).edit().putBoolean("biometric_enabled", true).commit();
                        sendResult(callback, true, "");
                    }
                    @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                        sendResult(callback, false, errString == null ? "احراز هویت ناموفق بود." : errString.toString());
                    }
                    @Override public void onAuthenticationFailed() { /* Prompt remains available for another attempt. */ }
                });
                biometricPromptInfo = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(enabling ? "فعال‌سازی ورود با اثر انگشت" : "ورود به سامانه با اثر انگشت")
                    .setSubtitle("از اثر انگشت ثبت‌شده در گوشی استفاده کنید")
                    .setNegativeButtonText("انصراف")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .build();
                biometricPrompt.authenticate(biometricPromptInfo);
            });
        }
        private void sendResult(String callback, boolean success, String message) {
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(callback + "(" + success + "," + org.json.JSONObject.quote(message) + ")", null); });
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                              WindowManager.LayoutParams.FLAG_FULLSCREEN);
        assetLoader = new WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.addJavascriptInterface(new OfflineStorageBridge(this), "WasteOffline");
        webView.addJavascriptInterface(new BiometricBridge(), "WasteBiometric");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override public boolean shouldOverrideUrlLoading(
                WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                String host = uri.getHost() == null ? "" : uri.getHost();

                if ("https".equalsIgnoreCase(scheme) &&
                    (host.equals("appassets.androidplatform.net") ||
                     host.equals("mahdi27163-crypto.github.io") ||
                     host.equals("script.google.com") ||
                     host.equals("script.googleusercontent.com") ||
                     host.equals("accounts.google.com") ||
                     host.endsWith(".google.com") ||
                     host.endsWith(".googleusercontent.com") ||
                     host.equals("cdn.jsdelivr.net"))) {
                    return false;
                }

                if ("http".equalsIgnoreCase(scheme) ||
                    "https".equalsIgnoreCase(scheme) ||
                    "mailto".equalsIgnoreCase(scheme) ||
                    "tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                }
                return true;
            }
        });

        if (savedInstanceState == null) webView.loadUrl(APP_URL);
        else webView.restoreState(savedInstanceState);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
